const express = require('express')
const router = express.Router()

const AuthRouter            = require("../../controllers/AdminRouter/Auth")
const UserManagementRouter  = require("../../controllers/AdminRouter/UserManagement")
const TaxManagementRouter   = require("../../controllers/AdminRouter/TaxManagement")
const MerchantRouter        = require("../../controllers/AdminRouter/Merchant")
const ReceiptRouter         = require("../../controllers/AdminRouter/Receipt")
const ReceiptCategoryRouter = require("../../controllers/AdminRouter/ReceiptCategory")
const ExpenseRouter         = require("../../controllers/AdminRouter/Expense")
const ExpenseItemRouter     = require("../../controllers/AdminRouter/ExpenseItem")

router.use("/auth", AuthRouter)
router.use("/users", UserManagementRouter)
router.use("/tax", TaxManagementRouter)
router.use("/merchant", MerchantRouter)
router.use("/receipt", ReceiptRouter)
router.use("/receipt-category", ReceiptCategoryRouter)
router.use("/expense", ExpenseRouter)
router.use("/expense-item", ExpenseItemRouter)

module.exports = router
